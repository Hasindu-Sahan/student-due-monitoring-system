export { OfficePaymentsPage as default } from "@/components/portal/office-payments";
