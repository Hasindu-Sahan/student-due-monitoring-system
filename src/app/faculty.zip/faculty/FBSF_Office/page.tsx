export { OfficeDashboardPage as default } from "@/components/portal/office-portal";
